"""Agent 3 (Python) - Object Detection & Tracking API.  Run: python app.py  (port 5001)"""
from flask import Flask, request, jsonify
import cv2
from ultralytics import YOLOWorld

CONF, MIN_HITS, GONE_SEC, STRIDE = 0.30, 5, 2, 2   # STRIDE=2 -> analyse every 2nd frame (faster)

app = Flask(__name__)
model = YOLOWorld("yolov8s-worldv2.pt")            # open-vocabulary: any object name works


def near(obj, person, pad=0.5):
    w, h = obj[2] - obj[0], obj[3] - obj[1]
    return not (person[2] < obj[0] - pad * w or person[0] > obj[2] + pad * w or
                person[3] < obj[1] - pad * h or person[1] > obj[3] + pad * h)


@app.post("/detect")
def detect():
    data = request.get_json()
    video, name = data["video_path"], data["object"].strip()

    cap = cv2.VideoCapture(video)
    fps = cap.get(cv2.CAP_PROP_FPS) or 25
    width, height = int(cap.get(3)), int(cap.get(4))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    cap.release()

    model.predictor = None                          # reset tracker for each new video
    model.set_classes([name, "person"])             # class 0 = target, class 1 = person

    frames, hits, last_frame, person_near = [], 0, None, False
    for i, r in enumerate(model.track(video, stream=True, persist=True, conf=CONF,
                                      vid_stride=STRIDE, verbose=False)):
        frame_no = i * STRIDE
        objs = [b for b in r.boxes if int(b.cls) == 0]
        people = [b.xyxy[0].tolist() for b in r.boxes if int(b.cls) == 1]
        if not objs:
            continue
        boxes = []
        for b in objs:
            x1, y1, x2, y2 = b.xyxy[0].tolist()
            boxes.append({"x1": x1, "y1": y1, "x2": x2, "y2": y2,
                          "conf": round(float(b.conf), 2),
                          "id": int(b.id) if b.id is not None else -1})
        frames.append({"f": frame_no, "boxes": boxes})
        hits += 1
        last_frame = frame_no
        best = max(objs, key=lambda b: float(b.conf)).xyxy[0].tolist()
        person_near = any(near(best, p) for p in people)

    result = {"object": name, "fps": fps, "width": width, "height": height,
              "stride": STRIDE, "frames": frames}

    if hits < MIN_HITS:
        result.update(outcome="NOT_DETECTED", frames=[], last_seen_sec=None)
    else:
        gone = (total_frames - 1 - last_frame) > GONE_SEC * fps
        result.update(outcome="FOUND_WITH_ACTIVITY" if gone and person_near else "FOUND_NO_ACTIVITY",
                      last_seen_sec=round(last_frame / fps, 1))
    return jsonify(result)


if __name__ == "__main__":
    app.run(port=5001, threaded=False)
